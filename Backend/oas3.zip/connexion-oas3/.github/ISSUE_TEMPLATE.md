### Description



### Expected behaviour



### Actual behaviour



### Steps to reproduce



### Additional info:

Output of the commands:

- `python --version`
- `pip show connexion | grep "^Version\:"`
