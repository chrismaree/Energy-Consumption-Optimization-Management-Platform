# This is a test file, please do not delete.
# It is used by the test:
#  - `test_operation.py:test_invalid_operation_does_stop_application_to_setup`
#  - `test_api.py:test_invalid_operation_does_stop_application_to_setup`
#  - `test_api.py:test_invalid_operation_does_not_stop_application_in_debug_mode`
from foo.bar import foobar  # noqa
