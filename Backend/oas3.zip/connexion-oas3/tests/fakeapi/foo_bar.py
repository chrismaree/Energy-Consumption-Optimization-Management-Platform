#!/usr/bin/env python3


def search():
    return ''
