=====================
RestyResolver Example
=====================

Running:

.. code-block:: bash

    $ ./resty.py

Now open your browser and go to http://localhost:9090/v1.0/ui/ to see the Swagger UI.
